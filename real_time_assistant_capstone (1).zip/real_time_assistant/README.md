# Omniscient ADK Concierge Assistant
## Overview
A high-scoring multi-agent system demonstrating Sequential, Parallel, and Loop flows, Code Execution, and MemoryBank for dynamic real-time work management.
## Setup
1. Set the GEMINI_API_KEY environment variable.
2. Run `python run.py`.
